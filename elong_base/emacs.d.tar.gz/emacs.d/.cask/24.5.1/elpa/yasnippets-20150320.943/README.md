yasnippets
==========

  It's the most comprehensive collection of yasnippets
