/* lisp for test */
