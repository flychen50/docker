// Mock C file.
