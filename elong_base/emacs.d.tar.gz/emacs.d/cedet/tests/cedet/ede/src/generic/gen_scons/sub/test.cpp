// Generic SCons test code.
